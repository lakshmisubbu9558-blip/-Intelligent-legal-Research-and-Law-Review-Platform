import { useEffect, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import api from "../api";

export default function Dashboard() {
  const [s, setS] = useState<{ documents: number; activity: Record<string, number> }>({ documents: 0, activity: {} });
  useEffect(() => {
    api.get("/stats").then((r) => setS(r.data));
  }, []);
  const data = Object.entries(s.activity).map(([name, count]) => ({ name, count }));
  const total = data.reduce((a, b) => a + b.count, 0);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card"><div className="text-sm text-slate-500">Documents available</div><div className="text-3xl font-bold">{s.documents}</div></div>
        <div className="card"><div className="text-sm text-slate-500">Research actions</div><div className="text-3xl font-bold">{total}</div></div>
      </div>
      <div className="card h-72">
        <div className="mb-2 text-sm font-medium">Your activity</div>
        {data.length ? (
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={data}>
              <XAxis dataKey="name" /><YAxis allowDecimals={false} /><Tooltip />
              <Bar dataKey="count" fill="#4338ca" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-sm text-slate-500">No activity yet. Try the Research & Chat page.</p>
        )}
      </div>
      <p className="text-xs text-slate-500">For academic research assistance only. Not a substitute for a qualified legal professional.</p>
    </div>
  );
}
