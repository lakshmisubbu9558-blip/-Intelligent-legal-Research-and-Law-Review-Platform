import { useState } from "react";
import { Search, Send } from "lucide-react";
import api, { errMsg } from "../api";

function Sources({ items }: { items: any[] }) {
  if (!items?.length) return null;
  return (
    <div className="space-y-2">
      <div className="text-sm font-medium">Sources</div>
      {items.map((s) => (
        <div key={s.label} className="rounded-lg border bg-slate-50 p-3 text-sm">
          <div className="font-medium">[{s.label}] {s.title} · page {s.page} <span className="text-xs text-slate-400">relevance {s.score}</span></div>
          <p className="mt-1 text-slate-600">{s.snippet}</p>
        </div>
      ))}
    </div>
  );
}

export default function Research() {
  const [mode, setMode] = useState<"chat" | "search">("chat");
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState("");
  const [sources, setSources] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const run = async () => {
    if (!q.trim()) return;
    setBusy(true); setErr(""); setAnswer(""); setSources([]);
    try {
      if (mode === "chat") {
        const { data } = await api.post("/chat", { query: q });
        setAnswer(data.answer); setSources(data.sources);
      } else {
        const { data } = await api.post("/search", { query: q });
        setSources(data.results);
        if (!data.results.length) setAnswer("No matching passages found.");
      }
    } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  };

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-semibold">Legal Research</h1>
      <div className="flex gap-2">
        <button className={mode === "chat" ? "btn" : "btn-light"} onClick={() => setMode("chat")}>Ask AI</button>
        <button className={mode === "search" ? "btn" : "btn-light"} onClick={() => setMode("search")}>Search passages</button>
      </div>
      <div className="flex gap-2">
        <input className="input" placeholder={mode === "chat" ? "Ask a legal research question..." : "Search laws and judgments..."}
          value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} />
        <button className="btn flex items-center gap-2" onClick={run} disabled={busy}>
          {mode === "chat" ? <Send size={16} /> : <Search size={16} />} {busy ? "Working..." : "Go"}
        </button>
      </div>
      {err && <div className="text-sm text-red-600">{err}</div>}
      {answer && <div className="card whitespace-pre-wrap text-sm leading-relaxed">{answer}</div>}
      <Sources items={sources} />
    </div>
  );
}
