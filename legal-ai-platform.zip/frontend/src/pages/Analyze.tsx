import { useEffect, useState } from "react";
import api, { errMsg } from "../api";

export default function Analyze() {
  const [docs, setDocs] = useState<any[]>([]);
  const [a, setA] = useState<number | "">("");
  const [b, setB] = useState<number | "">("");
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => { api.get("/documents").then((r) => setDocs(r.data)); }, []);

  const run = async (path: string, body?: any) => {
    setBusy(true); setErr(""); setOut("");
    try { const { data } = await api.post(path, body); setOut(data.result); } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  };

  const Select = ({ v, set }: { v: number | ""; set: (n: number | "") => void }) => (
    <select className="input" value={v} onChange={(e) => set(e.target.value ? Number(e.target.value) : "")}>
      <option value="">Select document...</option>
      {docs.map((d) => <option key={d.id} value={d.id}>{d.title}</option>)}
    </select>
  );

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-semibold">Analyze Documents</h1>
      <div className="card space-y-3">
        <div className="text-sm font-medium">Summarize or review a document</div>
        <Select v={a} set={setA} />
        <div className="flex gap-2">
          <button className="btn" disabled={!a || busy} onClick={() => run(`/documents/${a}/summarize`)}>Summarize judgment</button>
          <button className="btn" disabled={!a || busy} onClick={() => run(`/documents/${a}/review`)}>Review document / contract</button>
        </div>
      </div>
      <div className="card space-y-3">
        <div className="text-sm font-medium">Compare two documents</div>
        <div className="grid gap-3 sm:grid-cols-2"><Select v={a} set={setA} /><Select v={b} set={setB} /></div>
        <button className="btn" disabled={!a || !b || busy} onClick={() => run("/compare", { doc_a: a, doc_b: b })}>Compare</button>
      </div>
      {busy && <div className="text-sm text-slate-500">Claude is analyzing...</div>}
      {err && <div className="text-sm text-red-600">{err}</div>}
      {out && <div className="card whitespace-pre-wrap text-sm leading-relaxed">{out}</div>}
    </div>
  );
}
