import { useState } from "react";
import api, { errMsg } from "../api";

export default function Report() {
  const [topic, setTopic] = useState("");
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const run = async () => {
    setBusy(true); setErr(""); setOut("");
    try { const { data } = await api.post("/report", { query: topic }); setOut(data.result); } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  };

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-semibold">Research Report Generator</h1>
      <div className="flex gap-2">
        <input className="input" placeholder="Topic, e.g. enforceability of oral agreements for property sale" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <button className="btn" onClick={run} disabled={!topic.trim() || busy}>{busy ? "Writing..." : "Generate"}</button>
      </div>
      {err && <div className="text-sm text-red-600">{err}</div>}
      {out && (
        <>
          <button className="btn-light" onClick={() => navigator.clipboard.writeText(out)}>Copy report</button>
          <div className="card whitespace-pre-wrap text-sm leading-relaxed">{out}</div>
        </>
      )}
    </div>
  );
}
