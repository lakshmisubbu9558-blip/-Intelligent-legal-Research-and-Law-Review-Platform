import { useEffect, useState } from "react";
import { Trash2, Upload } from "lucide-react";
import api, { errMsg } from "../api";

export default function Documents() {
  const [docs, setDocs] = useState<any[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [type, setType] = useState("judgment");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => api.get("/documents").then((r) => setDocs(r.data));
  useEffect(() => { load(); }, []);

  const upload = async () => {
    if (!file) return;
    setBusy(true); setMsg("");
    const fd = new FormData();
    fd.append("file", file); fd.append("title", title); fd.append("doc_type", type);
    try {
      await api.post("/documents", fd);
      setFile(null); setTitle(""); setMsg("Uploaded successfully.");
      load();
    } catch (e) { setMsg(errMsg(e)); }
    setBusy(false);
  };

  const del = async (id: number) => {
    if (!confirm("Delete this document?")) return;
    try { await api.delete(`/documents/${id}`); load(); } catch (e) { setMsg(errMsg(e)); }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Documents</h1>
      <div className="card space-y-3">
        <div className="text-sm font-medium">Upload a legal document (PDF, DOCX, TXT)</div>
        <div className="grid gap-3 sm:grid-cols-3">
          <input className="input" placeholder="Title (optional)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <select className="input" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="judgment">Judgment</option><option value="statute">Statute / Act</option>
            <option value="contract">Contract</option><option value="article">Article / Other</option>
          </select>
          <input className="input" type="file" accept=".pdf,.docx,.txt,.md" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </div>
        <button className="btn flex items-center gap-2" onClick={upload} disabled={!file || busy}><Upload size={16} /> {busy ? "Processing..." : "Upload"}</button>
        {msg && <div className="text-sm text-slate-600">{msg}</div>}
      </div>
      <div className="card">
        <table className="w-full text-left text-sm">
          <thead className="text-slate-500"><tr><th className="py-2">Title</th><th>Type</th><th>Size</th><th /></tr></thead>
          <tbody>
            {docs.map((d) => (
              <tr key={d.id} className="border-t">
                <td className="py-2">{d.title} {d.shared && <span className="ml-1 rounded bg-amber-100 px-2 py-0.5 text-xs text-amber-800">shared demo</span>}</td>
                <td className="capitalize">{d.doc_type}</td><td>{Math.round(d.chars / 1000)}k chars</td>
                <td className="text-right">{!d.shared && <button onClick={() => del(d.id)} className="text-red-600"><Trash2 size={16} /></button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
