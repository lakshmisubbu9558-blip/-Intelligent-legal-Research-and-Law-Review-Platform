import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Scale } from "lucide-react";
import api, { errMsg } from "../api";

export default function Login() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    try {
      const { data } = await api.post(`/auth/${mode}`, f);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      nav("/");
    } catch (e) {
      setErr(errMsg(e));
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-indigo-950 p-4">
      <form onSubmit={submit} className="card w-full max-w-sm space-y-3">
        <div className="flex items-center gap-2 text-xl font-semibold text-indigo-900">
          <Scale /> Legal Research Platform
        </div>
        <p className="text-sm text-slate-500">{mode === "login" ? "Sign in to continue" : "Create your account"}</p>
        {mode === "register" && (
          <input className="input" placeholder="Full name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required />
        )}
        <input className="input" type="email" placeholder="Email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required />
        <input className="input" type="password" placeholder="Password (min 6 chars)" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} required />
        {err && <div className="text-sm text-red-600">{err}</div>}
        <button className="btn w-full">{mode === "login" ? "Sign in" : "Register"}</button>
        <button type="button" className="w-full text-sm text-indigo-700" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "New here? Create an account" : "Have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
