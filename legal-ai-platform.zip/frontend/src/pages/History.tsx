import { useEffect, useState } from "react";
import api from "../api";

export default function History() {
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState<number | null>(null);
  useEffect(() => { api.get("/history").then((r) => setRows(r.data)); }, []);
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Research History</h1>
      {rows.length === 0 && <p className="text-sm text-slate-500">Nothing here yet.</p>}
      {rows.map((h) => (
        <div key={h.id} className="card cursor-pointer" onClick={() => setOpen(open === h.id ? null : h.id)}>
          <div className="flex justify-between text-sm">
            <span><b className="uppercase text-indigo-700">{h.kind}</b> · {h.query}</span>
            <span className="text-slate-400">{new Date(h.created_at).toLocaleString()}</span>
          </div>
          {open === h.id && <div className="mt-3 whitespace-pre-wrap border-t pt-3 text-sm">{h.result}</div>}
        </div>
      ))}
    </div>
  );
}
