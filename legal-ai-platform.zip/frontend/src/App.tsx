import { Navigate, NavLink, Outlet, Route, Routes, useNavigate } from "react-router-dom";
import { BarChart3, FileText, History as HistoryIcon, LogOut, MessageSquare, Scale, ScrollText, Wand2 } from "lucide-react";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Documents from "./pages/Documents";
import Research from "./pages/Research";
import Analyze from "./pages/Analyze";
import Report from "./pages/Report";
import History from "./pages/History";

const nav = [
  { to: "/", label: "Dashboard", icon: BarChart3 },
  { to: "/documents", label: "Documents", icon: FileText },
  { to: "/research", label: "Research & Chat", icon: MessageSquare },
  { to: "/analyze", label: "Analyze", icon: Wand2 },
  { to: "/report", label: "Reports", icon: ScrollText },
  { to: "/history", label: "History", icon: HistoryIcon },
];

function Layout() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  if (!localStorage.getItem("token")) return <Navigate to="/login" replace />;
  const logout = () => {
    localStorage.clear();
    navigate("/login");
  };
  return (
    <div className="flex min-h-screen">
      <aside className="flex w-60 flex-col bg-indigo-950 p-4 text-indigo-100">
        <div className="mb-6 flex items-center gap-2 text-lg font-semibold text-white">
          <Scale size={22} /> LegalAI
        </div>
        <nav className="flex-1 space-y-1">
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${isActive ? "bg-indigo-700 text-white" : "hover:bg-indigo-900"}`
              }
            >
              <Icon size={16} /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-indigo-800 pt-3 text-xs">
          <div className="mb-2 truncate">{user.name}</div>
          <button onClick={logout} className="flex items-center gap-1 text-indigo-300 hover:text-white">
            <LogOut size={14} /> Log out
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto p-8">
        <Outlet />
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/documents" element={<Documents />} />
        <Route path="/research" element={<Research />} />
        <Route path="/analyze" element={<Analyze />} />
        <Route path="/report" element={<Report />} />
        <Route path="/history" element={<History />} />
      </Route>
    </Routes>
  );
}
