import io
from fastapi import HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session
from .config import ANTHROPIC_API_KEY, CLAUDE_MODEL
from . import models


def ask_claude(system: str, user: str, max_tokens: int = 1800) -> str:
    if not ANTHROPIC_API_KEY:
        return ("⚠️ ANTHROPIC_API_KEY is not set. Add it to backend/.env and restart the server "
                "to enable AI answers. Retrieved sources are still shown below.")
    try:
        from anthropic import Anthropic

        client = Anthropic(api_key=ANTHROPIC_API_KEY)
        msg = client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    except Exception as e:  # surface API problems cleanly
        raise HTTPException(502, f"Claude API error: {e}")


# ---------- document processing ----------
def extract_pages(filename: str, data: bytes):
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if ext == "pdf":
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        return [(i + 1, p.extract_text() or "") for i, p in enumerate(reader.pages)]
    if ext == "docx":
        import docx

        d = docx.Document(io.BytesIO(data))
        return [(1, "\n".join(p.text for p in d.paragraphs))]
    if ext in ("txt", "md"):
        return [(1, data.decode("utf-8", "ignore"))]
    raise HTTPException(400, "Unsupported file type. Upload PDF, DOCX or TXT.")


def chunk_text(text: str, size: int = 1000, overlap: int = 150):
    text = " ".join(text.split())
    chunks, i = [], 0
    while i < len(text):
        chunks.append(text[i : i + size])
        i += size - overlap
    return chunks


def save_document(db: Session, owner_id, title, doc_type, filename, pages):
    full = "\n\n".join(t for _, t in pages)
    doc = models.Document(owner_id=owner_id, title=title, doc_type=doc_type, filename=filename, text=full)
    db.add(doc)
    db.flush()
    for page, text in pages:
        for c in chunk_text(text):
            db.add(models.Chunk(document_id=doc.id, page=page, content=c))
    db.commit()
    return doc


# ---------- retrieval (TF-IDF based RAG) ----------
def retrieve(db: Session, user, query: str, k: int = 5, doc_ids=None):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    q = (
        db.query(models.Chunk, models.Document)
        .join(models.Document, models.Chunk.document_id == models.Document.id)
        .filter(or_(models.Document.owner_id == user.id, models.Document.owner_id.is_(None)))
    )
    if doc_ids:
        q = q.filter(models.Document.id.in_(doc_ids))
    rows = q.all()
    if not rows:
        return []
    texts = [c.content for c, _ in rows]
    try:
        m = TfidfVectorizer(stop_words="english", ngram_range=(1, 2)).fit_transform(texts + [query])
    except ValueError:
        return []
    sims = cosine_similarity(m[-1], m[:-1]).ravel()
    out = []
    for n, i in enumerate(sims.argsort()[::-1][:k]):
        if sims[i] <= 0:
            continue
        c, d = rows[i]
        out.append(
            {"label": f"S{len(out) + 1}", "doc_id": d.id, "title": d.title, "page": c.page,
             "snippet": c.content, "score": round(float(sims[i]), 3)}
        )
    return out


def build_context(sources) -> str:
    return "\n\n".join(f"[{s['label']}] {s['title']} (page {s['page']}):\n{s['snippet']}" for s in sources)
