from . import models, ai

DEMO_DOCS = [
    ("DEMO (fictional): Rental Agreement", "contract", """RESIDENTIAL RENTAL AGREEMENT (fictional demo document).
This agreement is made between Mr. A (Landlord) and Ms. B (Tenant). The monthly rent is fixed and payable by the
5th of each month. The security deposit equals three months of rent and is refundable without interest after the
tenant vacates. The landlord may terminate this agreement at any time without notice. The tenant must give three
months written notice before vacating. The tenant shall bear all structural repair costs. Disputes shall be
resolved only in the courts chosen solely by the landlord. The agreement contains no clause on subletting,
force majeure, or maintenance responsibilities for common areas."""),
    ("DEMO (fictional): Sharma v. Verma - Judgment", "judgment", """SHARMA v. VERMA (fictional demo judgment for testing only).
Facts: The appellant Sharma entered into an oral agreement to sell a plot of land to the respondent Verma and
received an advance payment. Sharma later refused to execute the sale deed, claiming the agreement was unenforceable
because it was not in writing. Issues: (1) Whether an oral agreement for sale of immovable property is enforceable.
(2) Whether part performance by payment of advance can protect the buyer. Arguments: The appellant argued that
immovable property transfers require a written and registered instrument. The respondent argued that the advance
payment and taking of possession amounted to part performance. Holding: The court held that mere payment of an
advance, without delivery of possession, does not amount to part performance, and the oral agreement could not be
specifically enforced. The respondent may recover the advance with reasonable interest. Significance: The decision
stresses the need for written, registered instruments in property transactions."""),
]


def seed(db):
    if db.query(models.Document).filter(models.Document.owner_id.is_(None)).count():
        return
    for title, dtype, text in DEMO_DOCS:
        ai.save_document(db, None, title, dtype, "demo.txt", [(1, text)])
