from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from .database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    password_hash = Column(String(300), nullable=False)
    role = Column(String(20), default="user")  # user | lawyer | admin
    created_at = Column(DateTime, default=datetime.utcnow)


class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # None = shared demo doc
    title = Column(String(300), nullable=False)
    doc_type = Column(String(50), default="judgment")  # judgment | statute | contract | article
    filename = Column(String(300), default="")
    text = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    chunks = relationship("Chunk", cascade="all, delete-orphan", back_populates="document")


class Chunk(Base):
    __tablename__ = "chunks"
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("documents.id"), index=True)
    page = Column(Integer, default=1)
    content = Column(Text, nullable=False)
    document = relationship("Document", back_populates="chunks")


class History(Base):
    __tablename__ = "history"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)
    kind = Column(String(30))  # chat | search | summary | review | compare | report
    query = Column(Text)
    result = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
