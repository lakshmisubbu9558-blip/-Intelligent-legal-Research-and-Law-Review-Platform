from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from sqlalchemy import or_
from sqlalchemy.orm import Session
from .database import get_db
from . import models, auth, ai, prompts

router = APIRouter(prefix="/api")


# ---------- schemas ----------
class RegisterIn(BaseModel):
    name: str
    email: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


class QueryIn(BaseModel):
    query: str


class CompareIn(BaseModel):
    doc_a: int
    doc_b: int


# ---------- helpers ----------
def user_out(u):
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role}


def visible_docs(db, user):
    return db.query(models.Document).filter(
        or_(models.Document.owner_id == user.id, models.Document.owner_id.is_(None))
    )


def get_doc(db, user, doc_id):
    d = visible_docs(db, user).filter(models.Document.id == doc_id).first()
    if not d:
        raise HTTPException(404, "Document not found")
    return d


def log(db, user, kind, query, result):
    db.add(models.History(user_id=user.id, kind=kind, query=query, result=result))
    db.commit()


# ---------- auth ----------
@router.post("/auth/register")
def register(body: RegisterIn, db: Session = Depends(get_db)):
    if len(body.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    email = body.email.strip().lower()
    if db.query(models.User).filter_by(email=email).first():
        raise HTTPException(400, "Email already registered")
    u = models.User(name=body.name.strip(), email=email, password_hash=auth.hash_password(body.password))
    db.add(u)
    db.commit()
    return {"token": auth.create_token(u.id), "user": user_out(u)}


@router.post("/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.query(models.User).filter_by(email=body.email.strip().lower()).first()
    if not u or not auth.verify_password(body.password, u.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"token": auth.create_token(u.id), "user": user_out(u)}


@router.get("/auth/me")
def me(user=Depends(auth.current_user)):
    return user_out(user)


# ---------- documents ----------
@router.get("/documents")
def list_docs(db: Session = Depends(get_db), user=Depends(auth.current_user)):
    docs = visible_docs(db, user).order_by(models.Document.created_at.desc()).all()
    return [
        {"id": d.id, "title": d.title, "doc_type": d.doc_type, "filename": d.filename,
         "shared": d.owner_id is None, "chars": len(d.text), "created_at": d.created_at.isoformat()}
        for d in docs
    ]


@router.post("/documents")
async def upload_doc(
    file: UploadFile = File(...),
    title: str = Form(""),
    doc_type: str = Form("judgment"),
    db: Session = Depends(get_db),
    user=Depends(auth.current_user),
):
    data = await file.read()
    if len(data) > 15 * 1024 * 1024:
        raise HTTPException(400, "File too large (max 15 MB)")
    pages = ai.extract_pages(file.filename or "", data)
    if not any(t.strip() for _, t in pages):
        raise HTTPException(400, "No readable text found (scanned PDFs need OCR).")
    doc = ai.save_document(db, user.id, title or file.filename, doc_type, file.filename or "", pages)
    return {"id": doc.id, "title": doc.title}


@router.get("/documents/{doc_id}")
def read_doc(doc_id: int, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    d = get_doc(db, user, doc_id)
    return {"id": d.id, "title": d.title, "doc_type": d.doc_type, "text": d.text}


@router.delete("/documents/{doc_id}")
def delete_doc(doc_id: int, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    d = get_doc(db, user, doc_id)
    if d.owner_id != user.id:
        raise HTTPException(403, "Shared demo documents cannot be deleted")
    db.delete(d)
    db.commit()
    return {"ok": True}


# ---------- research ----------
@router.post("/search")
def search(body: QueryIn, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    results = ai.retrieve(db, user, body.query, k=8)
    log(db, user, "search", body.query, f"{len(results)} results")
    return {"results": results}


@router.post("/chat")
def chat(body: QueryIn, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    sources = ai.retrieve(db, user, body.query, k=6)
    if not sources:
        return {"answer": "No relevant documents found. Upload documents first." + prompts.DISCLAIMER, "sources": []}
    prompt = f"Source excerpts:\n{ai.build_context(sources)}\n\nQuestion: {body.query}"
    answer = ai.ask_claude(prompts.CHAT, prompt) + prompts.DISCLAIMER
    log(db, user, "chat", body.query, answer)
    return {"answer": answer, "sources": sources}


@router.post("/documents/{doc_id}/summarize")
def summarize(doc_id: int, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    d = get_doc(db, user, doc_id)
    out = ai.ask_claude(prompts.SUMMARY, f"Title: {d.title}\n\n{d.text[:60000]}", 2000) + prompts.DISCLAIMER
    log(db, user, "summary", d.title, out)
    return {"result": out}


@router.post("/documents/{doc_id}/review")
def review(doc_id: int, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    d = get_doc(db, user, doc_id)
    out = ai.ask_claude(prompts.REVIEW, f"Title: {d.title}\n\n{d.text[:60000]}", 2000) + prompts.DISCLAIMER
    log(db, user, "review", d.title, out)
    return {"result": out}


@router.post("/compare")
def compare(body: CompareIn, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    a, b = get_doc(db, user, body.doc_a), get_doc(db, user, body.doc_b)
    prompt = f"DOCUMENT A: {a.title}\n{a.text[:25000]}\n\nDOCUMENT B: {b.title}\n{b.text[:25000]}"
    out = ai.ask_claude(prompts.COMPARE, prompt, 2000) + prompts.DISCLAIMER
    log(db, user, "compare", f"{a.title} vs {b.title}", out)
    return {"result": out}


@router.post("/report")
def report(body: QueryIn, db: Session = Depends(get_db), user=Depends(auth.current_user)):
    sources = ai.retrieve(db, user, body.query, k=8)
    if not sources:
        raise HTTPException(400, "No relevant documents found. Upload documents first.")
    prompt = f"Topic: {body.query}\n\nSource excerpts:\n{ai.build_context(sources)}"
    out = ai.ask_claude(prompts.REPORT, prompt, 2500) + prompts.DISCLAIMER
    log(db, user, "report", body.query, out)
    return {"result": out, "sources": sources}


# ---------- history & stats ----------
@router.get("/history")
def history(db: Session = Depends(get_db), user=Depends(auth.current_user)):
    rows = db.query(models.History).filter_by(user_id=user.id).order_by(models.History.id.desc()).limit(100).all()
    return [{"id": h.id, "kind": h.kind, "query": h.query, "result": h.result,
             "created_at": h.created_at.isoformat()} for h in rows]


@router.get("/stats")
def stats(db: Session = Depends(get_db), user=Depends(auth.current_user)):
    kinds = {}
    for (k,) in db.query(models.History.kind).filter_by(user_id=user.id).all():
        kinds[k] = kinds.get(k, 0) + 1
    return {"documents": visible_docs(db, user).count(), "activity": kinds}
