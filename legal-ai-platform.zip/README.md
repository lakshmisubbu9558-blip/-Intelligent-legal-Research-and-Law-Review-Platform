# Intelligent Legal Research and Law Review Platform

AI-powered legal research tool: upload legal documents, search them, ask questions with cited answers,
summarize judgments, review contracts, compare documents and generate research reports using the Claude API.

**Stack:** React + Vite + TypeScript + Tailwind | FastAPI + SQLAlchemy + SQLite | TF-IDF retrieval (RAG) | Anthropic Claude

## Run locally (VS Code)

### 1. Backend (terminal 1)
```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # Mac/Linux: cp .env.example .env
# open backend/.env and paste your ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

### 2. Frontend (terminal 2)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173, register an account and start researching.
Two fictional demo documents are pre-loaded so you can test immediately.

## Features
Login/register (JWT) · document upload (PDF/DOCX/TXT) · passage search · cited AI chat · judgment summarizer ·
contract review · two-document comparison · report generator · history · dashboard charts

## Notes
- Get an API key at https://console.anthropic.com. Change the model with `CLAUDE_MODEL` in `.env`.
- Scanned (image-only) PDFs need OCR first.
- To use PostgreSQL, set `DATABASE_URL` and `pip install psycopg2-binary`.
- Demo documents are fictional. Use real, public legal sources for actual research.
- Academic aid only. Not legal advice.

## Structure
```
backend/app: main.py routes.py ai.py auth.py models.py prompts.py seed.py config.py database.py
frontend/src: App.tsx api.ts pages/(Login Dashboard Documents Research Analyze Report History)
```
